//
//  FestivalSchedule.m
//  CHIME
//
//  Created by Mai Hoai Nam on 3/8/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import "FestivalSchedule.h"

@implementation FestivalSchedule

@end
