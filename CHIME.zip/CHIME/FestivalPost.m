//
//  Festival Post.m
//  CHIME
//
//  Created by Mai Hoai Nam on 3/18/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import "FestivalPost.h"

@implementation FestivalPost

@end
