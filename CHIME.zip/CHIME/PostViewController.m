//
//  PostViewController.m
//  CHIME
//
//  Created by Mai Hoai Nam on 3/9/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import "PostViewController.h"
#import "ShareTableViewCell.h"
#import "LocationTableViewCell.h"
#import "Constants.h"
#import "FestivalPost.h"
#import "FBSDKShareKit/FBSDKShareKit.h"
@import Firebase;
@import Photos;
@interface PostViewController ()
@property (nonatomic, strong) NSMutableArray *listSocialNetwork;
@property (strong, nonatomic) FIRDatabaseReference *ref;
@property (strong, nonatomic) NSMutableArray<FIRDataSnapshot *> *messages;
@property (strong, nonatomic) FIRStorageReference *storageRef;
@property (nonatomic, strong) FIRRemoteConfig *remoteConfig;
@property (strong, nonatomic) NSString* fbStatus;
@property (strong, nonatomic) NSString* twStatus;


@end

@implementation PostViewController
@synthesize listPost;
- (void)viewDidLoad {
    [super viewDidLoad];
    listPost = [[NSMutableArray alloc] init];
    _ref = [[FIRDatabase database] reference];
    self.storageRef = [[FIRStorage storage] reference];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    _postText.delegate = self;
    _postText.text = @"What's on your mind?";
    _postText.textColor = [UIColor lightGrayColor];
    NSDictionary *facebook = @{@"image": @"FacebookLogoOff", @"name": @"Facebook"};
    NSDictionary *twitter = @{@"image": @"TwitterLogoOff", @"name": @"Twitter"};
    self.listSocialNetwork = [[NSMutableArray alloc] init];
    [self.listSocialNetwork addObject:facebook];
    [self.listSocialNetwork addObject:twitter];
}

- (void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.topItem.rightBarButtonItem = _postBtn;
    self.navigationController.navigationBar.topItem.leftBarButtonItem = _cancelBtn;
    self.navigationController.navigationBar.topItem.title = @"Post";
    
}
-(void)dismissKeyboard
{
    [_postText resignFirstResponder];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 2;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @"Share your post";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(tableView == _shareTableView){
        if(indexPath.section == 0){
            ShareTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ShareSociaNetwork" forIndexPath:indexPath];
            if(cell == nil){
                cell = [[ShareTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ShareSociaNetwork"];
            }
            NSInteger index = [indexPath row];
            if(index >=0 && index < [self.listSocialNetwork count] ){
                NSDictionary *socialNetwork = [[self listSocialNetwork] objectAtIndex:index];
                cell.name.text = [socialNetwork valueForKey:@"name"];
                cell.status.on = NO;
                UISwitch *switchView = [[UISwitch alloc] initWithFrame:CGRectZero];
                cell.accessoryView = switchView;
                //[switchView release];
                [switchView addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged];
                cell.logo.image = [UIImage imageNamed: [socialNetwork valueForKey:@"image" ]];
            }
            return cell;
        }
    }
    return nil;
}
- (void)switchChanged:(id)sender {
    UISwitch *switchInCell = (UISwitch *)sender;
    ShareTableViewCell * cell = (ShareTableViewCell*) switchInCell.superview;
    NSIndexPath * indexpath = [_shareTableView indexPathForCell:cell];
    switch (indexpath.row) {
        case 0:
            if(switchInCell.on){
                cell.logo.image = [UIImage imageNamed:@"FacebookLogo"];
                _fbStatus = @"YES";
            }else{
                cell.logo.image = [UIImage imageNamed:@"FacebookLogoOff"];
                _fbStatus = @"NO";

            }
                break;
        case 1:
            if(switchInCell.on){
                cell.logo.image = [UIImage imageNamed:@"TwitterLogo"];
                _twStatus = @"YES";
            }else{
                cell.logo.image = [UIImage imageNamed:@"TwitterLogoOff"];
                _twStatus = @"NO";
            }
            break;
        default:
            break;
    }
    NSLog( @"The switch is %@", switchInCell.on ? @"ON" : @"OFF" );
}
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if ([textView.text isEqualToString:@"What's on your mind?"]) {
        textView.text = @"\n\n\n\n\n\n#gmlstnjazz2017 #gmlstnjazz";
        textView.textColor = [UIColor blackColor];
    }
    [textView becomeFirstResponder];
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    if ([textView.text isEqualToString:@""]) {
        textView.text = @"What's on your mind?";
        textView.textColor = [UIColor lightGrayColor];
    }
    [textView resignFirstResponder];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)cancelBtnClicked:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
    //[[self navigationController] popViewControllerAnimated:YES];

}

- (IBAction)addPostPhotoClicked:(id)sender {
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@"Choose Your Picture"
                                 message:@""
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* takePhoto = [UIAlertAction
                                actionWithTitle:@"Take Photo"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction * action)
                                {
                                    UIImagePickerController * picker = [[UIImagePickerController alloc] init];
                                    picker.delegate = self;
                                    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                                    [self presentViewController:picker animated:YES completion:NULL];                             [view dismissViewControllerAnimated:YES completion:nil];
                                    
                                }];
    UIAlertAction* fromLibrary = [UIAlertAction
                                  actionWithTitle:@"Choose From Library"
                                  style:UIAlertActionStyleDefault
                                  handler:^(UIAlertAction * action)
                                  {
                                      UIImagePickerController * picker = [[UIImagePickerController alloc] init];
                                      picker.delegate = self;
                                      picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                      [self presentViewController:picker animated:YES completion:NULL];
                                      [view dismissViewControllerAnimated:YES completion:nil];
                                  }];
    
    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    
    
    [view addAction:takePhoto];
    [view addAction:fromLibrary];
    [view addAction:cancel];
    [self presentViewController:view animated:YES completion:nil];

}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage *pickedImage =info[UIImagePickerControllerOriginalImage];
    _postImage.image = pickedImage;
    [picker dismissViewControllerAnimated:YES completion:NULL];

}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (void)sendMessage:(NSDictionary *)data {
    //FestivalPost *post = [[FestivalPost alloc] init];
    NSMutableDictionary *mdata;
    if(data){
        mdata = [data mutableCopy];
    }else{
        mdata = [[NSMutableDictionary alloc] init];
    }
    mdata[UserpostFieldsname] = [FIRAuth auth].currentUser.displayName;
    mdata[UserpostUserEmail] = [FIRAuth auth].currentUser.email;
    CLLocationCoordinate2D coordinate = [self getLocation];
    mdata[UserpostLat] = [NSString stringWithFormat:@"%f", coordinate.latitude];
    mdata[UserpostLong] = [NSString stringWithFormat:@"%f", coordinate.longitude];
    mdata[UserpostFieldstext] = _postText.text;
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    mdata[UserpostTime] = [NSString stringWithFormat:@"%@", [dateFormatter stringFromDate:[NSDate date]]];
    mdata[UserpostFB] = _fbStatus;
    mdata[UserpostTW] = _twStatus;
    // Push data to Firebase Database
    [listPost addObject:mdata];
    [[[[_ref child:@"userpost"] child:[FIRAuth auth].currentUser.uid] childByAutoId] setValue:mdata];
}

-(CLLocationCoordinate2D) getLocation{
    CLLocationManager *locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    [locationManager startUpdatingLocation];
    CLLocation *location = [locationManager location];
    CLLocationCoordinate2D coordinate = [location coordinate];
    
    return coordinate;
}
- (IBAction)postBtnClicked:(id)sender {
    if(_postImage.image){
        UIImage *image = _postImage.image;
        NSData *imageData = UIImageJPEGRepresentation(image, 0.8);
        NSString *imagePath =
        [NSString stringWithFormat:@"%@/%lld.jpg",
         [FIRAuth auth].currentUser.uid,
         (long long)([NSDate date].timeIntervalSince1970 * 1000.0)];
        FIRStorageMetadata *metadata = [FIRStorageMetadata new];
        metadata.contentType = @"image/jpeg";
        [[_storageRef child:imagePath] putData:imageData metadata:metadata
                                    completion:^(FIRStorageMetadata * _Nullable metadata, NSError * _Nullable error) {
                                        if (error) {
                                            NSLog(@"Error uploading: %@", error);
                                            [self sendMessage:nil];
                                            return;
                                        }
                                        [self sendMessage:@{UserpostphotoURL:[_storageRef child:metadata.path].description}];
                                        //mdata[UserpostphotoURL] = [_storageRef child:metadata.path].description;
                                    }];
        FBSDKSharePhoto *photo = [[FBSDKSharePhoto alloc] init];
        photo.image = image;
        photo.userGenerated = YES;
        FBSDKSharePhotoContent *content = [[FBSDKSharePhotoContent alloc] init];
        content.photos = @[photo];
        content.hashtag = [FBSDKHashtag hashtagWithString:@"#gmlstnjazz2017 #gmlstnjazz"];
        FBSDKShareDialog *dialog = [[FBSDKShareDialog alloc] init];
        dialog.fromViewController = self;
        dialog.shareContent = content;
        dialog.mode = FBSDKShareDialogModeNative; // if you don't set this before canShow call, canShow would always return YES
        if (![dialog canShow]) {
            // fallback presentation when there is no FB app
            dialog.mode = FBSDKShareDialogModeFeedBrowser;
        }
        [dialog show];
    }else{
        [self sendMessage:nil];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
