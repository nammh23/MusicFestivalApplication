//
//  LocationTableViewCell.m
//  CHIME
//
//  Created by Mai Hoai Nam on 3/10/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import "LocationTableViewCell.h"

@implementation LocationTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)addLocationClicked:(id)sender {
}
@end
