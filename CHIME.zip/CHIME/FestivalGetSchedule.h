//
//  FestivalGetSchedule.h
//  CHIME
//
//  Created by Mai Hoai Nam on 3/28/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FestivalGetSchedule : NSObject
+(void)getAllSchedule:(NSString*) festival;

@end
