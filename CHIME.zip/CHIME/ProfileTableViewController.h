//
//  ProfileTableViewController.h
//  CHIME
//
//  Created by Mai Hoai Nam on 2/28/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileTableViewController : UITableViewController

@end
