//
//  FestivalTimelineTableViewController.m
//  CHIME
//
//  Created by Mai Hoai Nam on 3/9/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import "FestivalTimelineTableViewController.h"
#import "TimelineTableViewCell.h"
#import "Constants.h"
#import "FestivalGetPost.h"
@import Photos;
@import Firebase;

@interface FestivalTimelineTableViewController ()<UITableViewDataSource, UITableViewDelegate,
UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@property (strong, nonatomic) FIRDatabaseReference *ref;
@property (strong, nonatomic) NSMutableArray<NSDictionary *> *listPost;
@property (strong, nonatomic) FIRStorageReference *storageRef;
@property (nonatomic, strong) FIRRemoteConfig *remoteConfig;

@end

@implementation FestivalTimelineTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [FestivalGetPost getCurrentUserPost:[FIRAuth auth].currentUser.uid];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAllPostSuccess:) name:@"allCurrentUserPost" object:nil];
    _listPost = [[NSMutableArray alloc] init];
    [self configureStorage];
}
-(void)getAllPostSuccess:(NSNotification*)notification {
    if ([notification.name isEqualToString:@"allCurrentUserPost"]) {
        self.listPost = [notification.userInfo objectForKey:@"allCurrentUserPost"];
        [_clientTable reloadData];
    }
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.topItem.rightBarButtonItem = _addPostItem;
    self.navigationController.navigationBar.topItem.leftBarButtonItem = nil;
    self.navigationController.navigationBar.topItem.title = @"Timeline";

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)configureStorage {
    self.storageRef = [[FIRStorage storage] reference];
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _listPost.count;;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TimelineTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TimelineTableViewCell" forIndexPath:indexPath];
    if(cell == nil){
        cell = [[TimelineTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"TimelineTableViewCell"];
    }
    
    // Unpack message from Firebase DataSnapshot
    NSDictionary<NSString *, NSString *> *message = _listPost[indexPath.row];
    NSString *photoPath = [message[UserpostTime] stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString* avatarPath = [[Constants getPostPhotoDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png", photoPath]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
        NSString *imageURL = message[UserpostphotoURL];
        if(imageURL == nil){
            cell.postImage.hidden = YES;
        }else{
            cell.postImage.hidden = NO;
            if ([imageURL hasPrefix:@"gs://"]) {
                [[[FIRStorage storage] referenceForURL:imageURL] dataWithMaxSize:INT64_MAX
                                                                  completion:^(NSData *data, NSError *error) {
                                                                      if (error) {
                                                                          NSLog(@"Error downloading: %@", error);
                                                                          return;
                                                                      }
                                                                      UIImage *image = [UIImage imageWithData:data];
                                                                      cell.postImage.image = image;
                                                                      [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                                                                  }];
            } else {
                UIImage *image =  [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageURL]]];
                cell.postImage.image = image;
                [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
            }
        }
    }else{
        cell.postImage.hidden = NO;
        cell.postImage.image = [UIImage imageWithContentsOfFile:avatarPath];
    }
    if([message[UserpostFB] isEqualToString:@"YES"]){
        [cell.fbBtn setImage:[UIImage imageNamed:@"FacebookLogo"] forState:UIControlStateNormal];
    }else{
        [cell.fbBtn setImage:[UIImage imageNamed:@"FacebookLogoOff"] forState:UIControlStateNormal];
    }
    if([message[UserpostTW] isEqualToString:@"YES"]){
        [cell.twBtn setImage:[UIImage imageNamed:@"TwitterLogo"] forState:UIControlStateNormal];
    }else{
        [cell.twBtn setImage:[UIImage imageNamed:@"TwitterLogoOff"] forState:UIControlStateNormal];
    }
    cell.postText.text = message[UserpostFieldstext];
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
