//
//  CommunityTableViewController.m
//  CHIME
//
//  Created by Mai Hoai Nam on 3/29/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import "CommunityTableViewController.h"
#import "CommunityTableViewCell.h"
#import "Constants.h"
#import "FestivalGetPost.h"
#import "CommunityMapShowViewController.h"
#import "PostDetailViewController.h"
@import CoreText;
@import Photos;
@import Firebase;
@interface CommunityTableViewController ()<UITableViewDataSource, UITableViewDelegate,
UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@property (strong, nonatomic) FIRDatabaseReference *ref;
@property (strong, nonatomic) NSMutableArray<NSDictionary *> *listPost;
@property (strong, nonatomic) NSMutableArray<NSDictionary *> *listLastPost;
@property (strong, nonatomic) FIRStorageReference *storageRef;
@property (nonatomic, strong) FIRRemoteConfig *remoteConfig;

@end

@implementation CommunityTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [FestivalGetPost getOtherUserPost:[FIRAuth auth].currentUser.uid];
    [FestivalGetPost getLastUserPost];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAllPostSuccess:) name:@"allOtherUserPost" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAllLastPostSuccess:) name:@"allLastUserPost" object:nil];
    _listPost = [[NSMutableArray alloc] init];
    _listLastPost = [[NSMutableArray alloc] init];
    [self configureStorage];
}
-(void)getAllPostSuccess:(NSNotification*)notification {
    if ([notification.name isEqualToString:@"allOtherUserPost"]) {
        self.listPost = [notification.userInfo objectForKey:@"allOtherUserPost"];
        [_clientTable reloadData];
    }
}
-(void)getAllLastPostSuccess:(NSNotification*)notification {
    if ([notification.name isEqualToString:@"allLastUserPost"]) {
        self.listLastPost = [notification.userInfo objectForKey:@"allLastUserPost"];
    }
}



- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.topItem.rightBarButtonItem = _mapBtn;
    self.navigationController.navigationBar.topItem.leftBarButtonItem = nil;
    self.navigationController.navigationBar.topItem.title = @"Community";
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)configureStorage {
    self.storageRef = [[FIRStorage storage] reference];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _listPost.count;;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    CommunityTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommunityTableViewCell" forIndexPath:indexPath];
    if(cell == nil){
        cell = [[CommunityTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CommunityTableViewCell"];
    }
    
    // Unpack message from Firebase DataSnapshot
    NSDictionary<NSString *, NSString *> *message = _listPost[indexPath.row];
    NSString *photoPath = [message[UserpostTime] stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSString* avatarPath = [[Constants getPostPhotoDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png", photoPath]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
        NSString *imageURL = message[UserpostphotoURL];
        if(imageURL == nil){
            cell.postImg.hidden = YES;
        }else{
            cell.postImg.hidden = NO;
            if ([imageURL hasPrefix:@"gs://"]) {
                [[[FIRStorage storage] referenceForURL:imageURL] dataWithMaxSize:INT64_MAX
                                                                      completion:^(NSData *data, NSError *error) {
                                                                          if (error) {
                                                                              NSLog(@"Error downloading: %@", error);
                                                                              return;
                                                                          }
                                                                          UIImage *image = [UIImage imageWithData:data];
                                                                          cell.postImg.image = image;
                                                                          [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                                                                      }];
            } else {
                UIImage *image =  [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageURL]]];
                cell.postImg.image = image;
                [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
            }
        }
    }else{
        cell.postImg.hidden = NO;
        cell.postImg.image = [UIImage imageWithContentsOfFile:avatarPath];
    }
    NSString* time =  [Constants calculateDate:message[UserpostTime]];
    NSString* postString = [NSString stringWithFormat:@"%@ posted a new status: \"%@\".\n%@", message[UserpostFieldsname], message[UserpostFieldstext],time ];
    UIFont *boldFont = [UIFont boldSystemFontOfSize:12];
    UIColor *color = [UIColor lightGrayColor];
    NSDictionary *dictColor = @{NSForegroundColorAttributeName : color };
    NSRange colorRange = NSMakeRange(postString.length-time.length, time.length);
    NSRange selectedRange = NSMakeRange(0, message[UserpostFieldsname].length);
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:postString];
    NSDictionary *dictBoldText = [NSDictionary dictionaryWithObjectsAndKeys:boldFont, NSFontAttributeName, nil];
    [string setAttributes:dictBoldText range:selectedRange];
    [string setAttributes:dictColor range:colorRange];
    cell.statusTxt.attributedText = string;
    
    NSString* imageURL = message[UserAvatar];
    UIImage *image = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageURL]]];
    if(image != nil){
        cell.userAvatarImg.image = image;
    }else{
        NSArray* name = [imageURL componentsSeparatedByString:@"/"];
        NSString *photoPath = name[name.count-1];
        NSString* avatarPath = [[Constants getPostPhotoDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@", photoPath]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
            cell.userAvatarImg.hidden = NO;
            if ([imageURL hasPrefix:@"gs://"]) {
                [[[FIRStorage storage] referenceForURL:imageURL] dataWithMaxSize:INT64_MAX
                                                                      completion:^(NSData *data, NSError *error) {
                                                                          if (error) {
                                                                              NSLog(@"Error downloading: %@", error);
                                                                              return;
                                                                          }
                                                                          UIImage *image = [UIImage imageWithData:data];
                                                                          cell.userAvatarImg.image = image;
                                                                          [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                                                                      }];
            } else {
                UIImage *image =  [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageURL]]];
                cell.userAvatarImg.image = image;
                [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
            }
        }else{
            cell.userAvatarImg.image = [UIImage imageWithContentsOfFile:avatarPath];
        }
        
    }
    cell.userAvatarImg.layer.cornerRadius = cell.userAvatarImg.frame.size.width/2;
    cell.userAvatarImg.clipsToBounds = YES;
    cell.userAvatarImg.layer.borderWidth = 2.0f;
    cell.userAvatarImg.layer.borderColor = [UIColor whiteColor].CGColor;

    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSIndexPath *indexPath = [[[self tableView] indexPathsForSelectedRows] objectAtIndex:0];
    UINavigationController* navController = segue.destinationViewController;
    if([segue.identifier isEqualToString:@"mapSegue"]){
        CommunityMapShowViewController* map = (CommunityMapShowViewController*)navController.topViewController;
        map.listPost = self.listLastPost;

    }else if ([segue.identifier isEqualToString:@"showPostSegue"]){
        NSDictionary<NSString *, NSString *> *post = [_listPost objectAtIndex:indexPath.row];
        PostDetailViewController* destController = [segue destinationViewController];
        destController.selectedPost = post;
    }
}


@end
