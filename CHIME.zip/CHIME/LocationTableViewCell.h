//
//  LocationTableViewCell.h
//  CHIME
//
//  Created by Mai Hoai Nam on 3/10/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocationTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *addLocationBtn;


@end
