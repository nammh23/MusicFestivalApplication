//
//  FestivalAttractionAnnotation.m
//  CHIME
//
//  Created by Mai Hoai Nam on 3/7/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import "FestivalAttractionAnnotation.h"

@implementation FestivalAttractionAnnotation

@end
