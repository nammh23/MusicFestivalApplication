//
//  FestivalScheduleTableViewController.h
//  CHIME
//
//  Created by Mai Hoai Nam on 3/7/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FestivalScheduleTableViewController : UITableViewController
@property (strong, nonatomic) IBOutlet UITableView *clientTable;
@property (strong, nonatomic) NSString* festival;
@end
