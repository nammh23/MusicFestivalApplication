//
//  PostDetailViewController.m
//  CHIME
//
//  Created by Mai Hoai Nam on 4/4/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import "PostDetailViewController.h"
#import "Constants.h"
@import Firebase;
@interface PostDetailViewController ()

@end

@implementation PostDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%@",_selectedPost);
    UIImage *image = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:_selectedPost[UserAvatar]]]];
    _profileImage.image = image;
    _profileImage.layer.cornerRadius = _profileImage.frame.size.width/2;
    _profileImage.clipsToBounds = YES;
    _profileImage.layer.borderWidth = 2.0f;
    _profileImage.layer.borderColor = [UIColor whiteColor].CGColor;
    
    NSString* time = [Constants calculateDate:_selectedPost[UserpostTime]];
    NSString* postString = [NSString stringWithFormat:@"%@ posted a new status.\n%@", _selectedPost[UserpostFieldsname], time ];
    UIFont *boldFont = [UIFont boldSystemFontOfSize:12];
    UIColor *color = [UIColor lightGrayColor];
    NSDictionary *dictColor = @{NSForegroundColorAttributeName : color };
    NSRange colorRange = NSMakeRange(postString.length-time.length, time.length);
    NSRange selectedRange = NSMakeRange(0, _selectedPost[UserpostFieldsname].length);
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:postString];
    NSDictionary *dictBoldText = [NSDictionary dictionaryWithObjectsAndKeys:boldFont, NSFontAttributeName, nil];
    [string setAttributes:dictBoldText range:selectedRange];
    [string setAttributes:dictColor range:colorRange];
    _inforText.attributedText = string;
    
    _postText.text = _selectedPost[UserpostFieldstext];
    CGFloat fixedWidth = _postText.frame.size.width;
    CGSize newSize = [_postText sizeThatFits:CGSizeMake(fixedWidth, MAXFLOAT)];
    CGRect newFrame = _postText.frame;
    newFrame.size = CGSizeMake(fmaxf(newSize.width, fixedWidth), newSize.height);
    _postText.frame = newFrame;
    NSString *imageURL = _selectedPost[UserpostphotoURL];
    if(imageURL == nil){
        _postImage.hidden = YES;
    }else{
        NSArray* name = [imageURL componentsSeparatedByString:@"/"];
        NSString *photoPath = name[name.count-1];
        NSString* avatarPath = [[Constants getPostPhotoDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@", photoPath]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
            _postImage.hidden = NO;
            if ([imageURL hasPrefix:@"gs://"]) {
                [[[FIRStorage storage] referenceForURL:imageURL] dataWithMaxSize:INT64_MAX
                                                                          completion:^(NSData *data, NSError *error) {
                                                                              if (error) {
                                                                                  NSLog(@"Error downloading: %@", error);
                                                                                  return;
                                                                              }
                                                                              UIImage *image = [UIImage imageWithData:data];
                                                                              _postImage.image = image;
                                                                              [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                                                                          }];
            } else {
                UIImage *image =  [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageURL]]];
                _postImage.image = image;
                [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
            }
        }else{
            _postImage.image = [UIImage imageWithContentsOfFile:avatarPath];
        }
    }
}

- (void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.topItem.rightBarButtonItem = nil;
    self.navigationController.navigationBar.topItem.leftBarButtonItem = nil;
    self.navigationController.navigationBar.topItem.title = @"Post Detail";

}
@end
