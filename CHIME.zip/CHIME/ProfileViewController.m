
//  ProfileViewController.m
//  CHIME
//
//  Created by Mai Hoai Nam on 2/27/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import "ProfileViewController.h"
#import "FBSDKCoreKit.h"
#import "FBSDKLoginKit.h"
#import "LoginViewController.h"
#import "ProfileTableViewCell.h"
#import "FestivalGetProfile.h"
#import "Constants.h"
@import Firebase;
@interface ProfileViewController ()
@property (nonatomic, strong) NSMutableArray *listPublicInfor;
@property (nonatomic, strong) NSMutableArray *listPrivateInfor;
@property (nonatomic, strong) NSMutableDictionary* data;
@property (strong, nonatomic) NSMutableArray<NSDictionary *> *userProfile;
@end

@implementation ProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[FIRAuth auth] addAuthStateDidChangeListener:^(FIRAuth *_Nonnull auth, FIRUser *_Nullable user) {
        if(user){
            [FestivalGetProfile getCurrentUserProfile:user.uid];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAllPostSuccess:) name:@"UserProfile" object:nil];
        }
    }];
    [_profilePic setUserInteractionEnabled:YES];
    UITapGestureRecognizer *singleTap =  [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapping:)];
    [singleTap setNumberOfTapsRequired:1];
    [_profilePic addGestureRecognizer:singleTap];
    _userProfile = [[NSMutableArray alloc] init];
    _listPublicInfor = [[NSMutableArray alloc] init];
    _listPrivateInfor = [[NSMutableArray alloc] init];
    _data = [[NSMutableDictionary alloc] init];
}
-(void)getAllPostSuccess:(NSNotification*)notification {
    if ([notification.name isEqualToString:@"UserProfile"]) {
        self.userProfile = [notification.userInfo objectForKey:@"UserProfile"];
        [_listPrivateInfor removeAllObjects];
        [_listPublicInfor removeAllObjects];
        for(NSDictionary *dict in self.userProfile){
            if([[[dict allKeys] objectAtIndex:0] isEqualToString:Username]){
                [_listPublicInfor addObject: @{@"image": @"Fullname",@"name":dict[Username]}];
            }else if([[[dict allKeys] objectAtIndex:0] isEqualToString:UserNickname]){
                [_listPublicInfor addObject: @{@"image": @"profile",@"name":dict[UserNickname]}];
            }else if([[[dict allKeys] objectAtIndex:0] isEqualToString:UserBio]){
                [_listPublicInfor addObject: @{@"image": @"Information",@"name":dict[UserBio]}];
            }else if([[[dict allKeys] objectAtIndex:0] isEqualToString:UserMail]){
                [_listPrivateInfor addObject: @{@"image": @"email",@"name":dict[UserMail]}];
            }else if([[[dict allKeys] objectAtIndex:0] isEqualToString:UserPhone]){
                [_listPrivateInfor addObject: @{@"image": @"mobile",@"name":dict[UserPhone]}];
            }else if([[[dict allKeys] objectAtIndex:0] isEqualToString:UserGender]){
                [_listPrivateInfor addObject: @{@"image": @"gender",@"name":dict[UserGender]}];
            }else if([[[dict allKeys] objectAtIndex:0] isEqualToString:UserAvatar]){
                [self getProfilePicture:dict[UserAvatar]];
            }
        }
        [_inforTableView reloadData];
    }
}

-(void)singleTapping:(UIGestureRecognizer *)recognizer {
    UIAlertController * view=   [UIAlertController
                                 alertControllerWithTitle:@"Change Profile Picture"
                                 message:@""
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* takePhoto = [UIAlertAction
                         actionWithTitle:@"Take Photo"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             UIImagePickerController * picker = [[UIImagePickerController alloc] init];
                             picker.delegate = self;
                             picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                             [self presentViewController:picker animated:YES completion:NULL];                             [view dismissViewControllerAnimated:YES completion:nil];
                             
                         }];
    UIAlertAction* fromLibrary = [UIAlertAction
                         actionWithTitle:@"Choose From Library"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             UIImagePickerController * picker = [[UIImagePickerController alloc] init];
                             picker.delegate = self;
                             picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                             [self presentViewController:picker animated:YES completion:NULL];
                             [view dismissViewControllerAnimated:YES completion:nil];
                         }];

    UIAlertAction* cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [view dismissViewControllerAnimated:YES completion:nil];
                                 
                             }];
    
    
    [view addAction:takePhoto];
    [view addAction:fromLibrary];
    [view addAction:cancel];
    [self presentViewController:view animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage *pickedImage =info[UIImagePickerControllerOriginalImage];
    _profilePic.image = pickedImage;
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:NULL];
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationController.navigationBar.topItem.title = @"Profile";
    self.navigationController.navigationController.navigationBar.topItem.rightBarButtonItem = _doneBtn;
    self.navigationController.navigationController.navigationBar.topItem.leftBarButtonItem = nil;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)getProfilePicture:(NSString*)imageURL {
    UIImage *image = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString: imageURL]]];
    if(image != nil){
        self.profilePic.image = image;
    }else{
        NSArray* name = [imageURL componentsSeparatedByString:@"/"];
        NSString *photoPath = name[name.count-1];
        NSString* avatarPath = [[Constants getPostPhotoDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@", photoPath]];
        if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
            self.profilePic.hidden = NO;
            if ([imageURL hasPrefix:@"gs://"]) {
                [[[FIRStorage storage] referenceForURL:imageURL] dataWithMaxSize:INT64_MAX
                                                                      completion:^(NSData *data, NSError *error) {
                                                                          if (error) {
                                                                              NSLog(@"Error downloading: %@", error);
                                                                              return;
                                                                          }
                                                                          UIImage *image = [UIImage imageWithData:data];
                                                                          self.profilePic.image = image;
                                                                          [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                                                                      }];
            } else {
                UIImage *image =  [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageURL]]];
                self.profilePic.image = image;
                [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
            }
        }else{
            self.profilePic.image = [UIImage imageWithContentsOfFile:avatarPath];
        }

    }
    self.profilePic.layer.cornerRadius = self.profilePic.frame.size.width/2;
    self.profilePic.clipsToBounds = YES;
    self.profilePic.layer.borderWidth = 3.0f;
    self.profilePic.layer.borderColor = [UIColor whiteColor].CGColor;

}

- (IBAction)logoutBtn:(id)sender{
    NSError *signOutError;
    BOOL status = [[FIRAuth auth] signOut:&signOutError];
    if (status) {
        LoginViewController *objSignUpViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"Login"];
        [self.navigationController pushViewController:objSignUpViewController animated:NO];
    }else{
        NSLog(@"Error signing out: %@", signOutError);
    }
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    // The header for the section is the region name -- get this from the region at the section index.
    if(section == 0)
        return @"";
    else
        return @"Private information";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(tableView == _inforTableView){
            ProfileTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ProfileInformation" forIndexPath:indexPath];
            if(cell == nil){
                cell = [[ProfileTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ProfileInformation"];
            }
            NSInteger index = [indexPath row];
        if(index >=0 && index < 3){
            if(indexPath.section == 0 && _listPublicInfor.count >0 ){
                NSDictionary *infor = [[self listPublicInfor] objectAtIndex:index];
                cell.textDisplay.text = [infor valueForKey:@"name"];
                self.data[Username] = cell.textDisplay.text;
                cell.icon.image = [UIImage imageNamed: [infor valueForKey:@"image" ]];
            }else if(indexPath.section == 1 && _listPrivateInfor.count >0 ){
                NSDictionary *infor = [[self listPrivateInfor] objectAtIndex:index];
                cell.textDisplay.text = [infor valueForKey:@"name"];
                self.data[UserGender] = cell.textDisplay.text;
                cell.icon.image = [UIImage imageNamed: [infor valueForKey:@"image" ]];
            }
        }
        return cell;
    }
    return nil;
}
- (IBAction)doneBtnClicked:(id)sender {
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
