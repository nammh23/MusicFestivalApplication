//
//  FestivalScheduleTableViewController.m
//  CHIME
//
//  Created by Mai Hoai Nam on 3/7/17.
//  Copyright © 2017 Mai Hoai Nam. All rights reserved.
//

#import "FestivalScheduleTableViewController.h"
#import "FestivalSchedule.h"
#import "FestivalScheduleTableViewCell.h"
#import "FestivalScheduleDetailViewController.h"
#import "FestivalGetSchedule.h"
#import "Constants.h"
@import Firebase;
@interface FestivalScheduleTableViewController ()
//@property (nonatomic) FestivalSchedule *selectedSchedule;
@property (readwrite) NSMutableDictionary *listAllSchedule;
@property (readwrite) NSMutableArray* listSchedule;
@end

@implementation FestivalScheduleTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //self.selectedSchedule = [[FestivalSchedule alloc] init];
    self.listAllSchedule = [[NSMutableDictionary alloc] init];
    self.listSchedule = [[NSMutableArray alloc] init];
    
    [FestivalGetSchedule getAllSchedule:@"festivalSchedule" ];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAllEventSuccess:) name:@"allSchedule" object:nil];
}
- (void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationController.navigationBar.topItem.rightBarButtonItem = nil;
    self.navigationController.navigationController.navigationBar.topItem.leftBarButtonItem = nil;
    self.navigationController.navigationController.navigationBar.topItem.title = @"Festival Schedule";
    
}

-(void)getAllEventSuccess:(NSNotification*)notification {
    if ([notification.name isEqualToString:@"allSchedule"]) {
        self.listAllSchedule = [notification.userInfo objectForKey:@"allSchedule"];
        NSDictionary* dicts = _listAllSchedule[@"GMLSTN"];
        NSArray* keys = [dicts allKeys];
        [_listSchedule removeAllObjects];
        for(NSString* key in keys){
            [_listSchedule addObject:[dicts objectForKey:key]];
        }
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"date" ascending:YES]; //sort by date key, ascending
        NSArray *arrayOfDescriptors = [NSArray arrayWithObject:sortDescriptor];
        
        [_listSchedule sortUsingDescriptors: arrayOfDescriptors];
        [_clientTable reloadData];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[self listSchedule] count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FestivalScheduleTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"listScheduleTable" forIndexPath:indexPath];
    if(cell == nil){
        cell = [[FestivalScheduleTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"listScheduleTable"];
    }
    NSInteger index = [indexPath row];
    if(index >=0 && index < [self.listSchedule count] ){
        NSDictionary<NSString *, NSString *> *message = [_listSchedule objectAtIndex:index];
        NSString *imageURL = message[@"image"];
        if(imageURL == nil){
            cell.scheduleImgView.hidden = YES;
        }else{
            NSArray* name = [imageURL componentsSeparatedByString:@"/"];
            NSString *photoPath = name[name.count-1];
            NSString* avatarPath = [[Constants getPostPhotoDirectory] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@", photoPath]];
            if ([[NSFileManager defaultManager] fileExistsAtPath:avatarPath] == NO) {
                cell.scheduleImgView.hidden = NO;
                if ([imageURL hasPrefix:@"gs://"]) {
                    [[[FIRStorage storage] referenceForURL:imageURL] dataWithMaxSize:INT64_MAX
                                                                          completion:^(NSData *data, NSError *error) {
                                                                              if (error) {
                                                                                  NSLog(@"Error downloading: %@", error);
                                                                                  return;
                                                                              }
                                                                              UIImage *image = [UIImage imageWithData:data];
                                                                              cell.scheduleImgView.image = image;
                                                                              [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                                                                          }];
                } else {
                    UIImage *image =  [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageURL]]];
                    cell.scheduleImgView.image = image;
                    [UIImagePNGRepresentation(image) writeToFile:avatarPath atomically:YES];
                }
            }else{
                cell.scheduleImgView.image = [UIImage imageWithContentsOfFile:avatarPath];
            }
        }
        cell.eventName.text = message[@"name"];
        cell.eventTime.text = message[@"date"];
    }
    
    return cell;
}

//-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    FestivalSchedule *schedule = [self.listSchedule objectAtIndex:indexPath.row];
//    self.selectedScheduleId = schedule.scheduleID;
//}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    NSIndexPath *indexPath = [[[self tableView] indexPathsForSelectedRows] objectAtIndex:0];
    NSDictionary<NSString *, NSString *> *schedule = [_listSchedule objectAtIndex:indexPath.row];
    //FestivalSchedule *schedule = [self.listSchedule objectAtIndex:indexPath.row];
    FestivalScheduleDetailViewController* destController = [segue destinationViewController];
    destController.selectedSchedule = schedule;

}


@end
